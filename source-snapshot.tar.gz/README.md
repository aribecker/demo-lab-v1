# SDD Full Stack Hello

Adaptación privada para Sites del proyecto Ariel/0080-prueba-SSD-full-stack.
Las fuentes originales, constitución, especificaciones y tests se conservan en original/.
El backend HTTP de Node se reemplaza por un Worker; el frontend y contrato JSON se preservan.

## Working files

The workspace checkout is the primary source. Preserve source checkpoints in the Site Git repository. Do not synchronize to OneDrive during iterations; export only when the user requests the final copy. Current UI release: 002. SDD specifications: original/specs/001-hello-full-stack. Previous specifications: history/.
